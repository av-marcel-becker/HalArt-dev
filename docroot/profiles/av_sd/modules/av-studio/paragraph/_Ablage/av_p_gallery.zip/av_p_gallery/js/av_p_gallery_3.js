import PhotoSwipeLightbox from '/libraries/PhotoSwipe-5.3.6/dist/photoswipe-lightbox.esm.js';
const options = {
      gallery: '.av-gallery',
      children: 'a',
      showHideAnimationType: 'zoom',
      pswpModule: () => import('/libraries/PhotoSwipe-5.3.6/dist/photoswipe.esm.js')
};
const lightbox = new PhotoSwipeLightbox(options);

   lightbox.on('uiRegister', function() 
      {
         lightbox.pswp.ui.registerElement(
            {
               name: 'custom-caption',
               order: 9,
               isButton: false,
               appendTo: 'root',
               html: 'Caption text',
               onInit: (el, pswp) => 
                  {
                     lightbox.pswp.on('change', () => 
                        {
                           const currSlideElement = lightbox.pswp.currSlide.data.element;
                           
                           let captionHTML = '';
                           const badge = currSlideElement.querySelector('.badge');
                           const badge_value = badge?' (' + badge.innerHTML + ')':'';
                           if(currSlideElement) 
                              {
                                 const hiddenCaption = currSlideElement.querySelector('figcaption');
                                 if(hiddenCaption) 
                                    {
                                       // get caption from element with class hidden-caption-content
                                       captionHTML = hiddenCaption.innerHTML + badge_value;
                                    }
                                 else 
                                    {
                                       // get caption from alt attribute
                                       captionHTML = currSlideElement.querySelector('img').getAttribute('alt') + badge_value;
                                    }
                              }
                           el.innerHTML = captionHTML || '' + badge_value;
                        });
                  }
            });
      });
      
    
let firstElWithBadge;
let lastElWithBadge;

// Gallery is starting to open
lightbox.on('afterInit', () => 
   {
      firstElWithBadge = lightbox.pswp.currSlide.data.element;
      hideBadge(firstElWithBadge);
   });

// Gallery is starting to close
lightbox.on('close', () =>    
   {
      lastElWithBadge = lightbox.pswp.currSlide.data.element;
      if(lastElWithBadge !== firstElWithBadge) 
         {
            showBadge(firstElWithBadge);
            hideBadge(lastElWithBadge);
         }
   });

// Gallery is closed
lightbox.on('destroy', () => 
   {
      showBadge(lastElWithBadge);
   });

lightbox.init();

function hideBadge(el) 
   {
     if(el.querySelector('.badge') !== null)
      {
         el.querySelector('.badge')
           .classList
           .add('badge--hidden');         
      }

}

function showBadge(el) 
   {
     if(el.querySelector('.badge') !== null)
      {
         el.querySelector('.badge')
           .classList
           .remove('badge--hidden');
      }    
   }
